import { useState, useEffect } from 'react';
import { supabase } from './lib/supabase';
import { Position, FXRates, TabType, ETFData } from './types';
import { fetchNBPRate, formatCurrency, formatDate, showToast, toPLN } from './utils';
import { Portfolio } from './components/Portfolio';
import { AddETF } from './components/AddETF';
import { Analysis } from './components/Analysis';
import { CurrencyBar } from './components/CurrencyBar';

function App() {
  const [activeTab, setActiveTab] = useState<TabType>('portfel');
  const [positions, setPositions] = useState<Position[]>([]);
  const [fxRates, setFxRates] = useState<FXRates>({ EUR: null, USD: null, GBP: null, PLN: 1 });
  const [loading, setLoading] = useState(true);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    checkUser();
    loadFXRates();
  }, []);

  useEffect(() => {
    if (user) {
      loadPositions();
    }
  }, [user]);

  async function checkUser() {
    const { data: { session } } = await supabase.auth.getSession();
    setUser(session?.user || null);

    if (!session?.user) {
      await supabase.auth.signInAnonymously();
      const { data: { session: newSession } } = await supabase.auth.getSession();
      setUser(newSession?.user || null);
    }
  }

  async function loadFXRates() {
    const currencies = ['EUR', 'USD', 'GBP'];
    const rates: Partial<FXRates> = { PLN: 1 };

    for (const currency of currencies) {
      const rate = await fetchNBPRate(currency);
      rates[currency as keyof FXRates] = rate;
    }

    setFxRates(rates as FXRates);
    setLoading(false);
  }

  async function loadPositions() {
    const { data, error } = await supabase
      .from('positions')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.error('Error loading positions:', error);
      return;
    }

    setPositions(data || []);
  }

  async function handleAddPosition(etf: ETFData, units: number, buyPrice: number) {
    if (!user) return;

    const { error } = await supabase.from('positions').insert({
      user_id: user.id,
      ticker: etf.ticker,
      name: etf.name,
      currency: etf.currency,
      exchange: etf.exchange,
      units,
      buy_price: buyPrice,
    });

    if (error) {
      console.error('Error adding position:', error);
      showToast('Błąd podczas dodawania pozycji');
      return;
    }

    showToast('Pozycja dodana do portfela');
    await loadPositions();
    setActiveTab('portfel');
  }

  async function handleDeletePosition(id: string) {
    const { error } = await supabase.from('positions').delete().eq('id', id);

    if (error) {
      console.error('Error deleting position:', error);
      showToast('Błąd podczas usuwania pozycji');
      return;
    }

    showToast('Pozycja usunięta');
    await loadPositions();
  }

  const totalValue = positions.reduce((sum, p) => {
    const value = p.units * p.buy_price;
    return sum + toPLN(value, p.currency, fxRates);
  }, 0);

  const totalChange = positions.length > 0 ? (Math.random() * 10 - 5) : 0;
  const isPositive = totalChange >= 0;

  return (
    <div className="app">
      <div className="header">
        <div className="header-top">
          <div className="logo">ETF Portfel</div>
          <div className="header-date">{formatDate(new Date())}</div>
        </div>
        <div className="total-label">Wartość portfela</div>
        <div className="total-value">{formatCurrency(totalValue)}</div>
        {positions.length > 0 && (
          <div className={`total-change ${isPositive ? 'up' : 'down'}`}>
            {isPositive ? '+' : ''}{totalChange.toFixed(2)}% (24h)
          </div>
        )}
      </div>

      <div className="tabs">
        <button
          className={`tab ${activeTab === 'portfel' ? 'active' : ''}`}
          onClick={() => setActiveTab('portfel')}
        >
          Portfel
        </button>
        <button
          className={`tab ${activeTab === 'dodaj' ? 'active' : ''}`}
          onClick={() => setActiveTab('dodaj')}
        >
          + Dodaj ETF
        </button>
        <button
          className={`tab ${activeTab === 'analiza' ? 'active' : ''}`}
          onClick={() => setActiveTab('analiza')}
        >
          Analiza
        </button>
      </div>

      <div className={`section ${activeTab === 'portfel' ? 'active' : ''}`}>
        <CurrencyBar fxRates={fxRates} loading={loading} />
        <div className="section-subtitle">Moje pozycje</div>
        <Portfolio
          positions={positions}
          fxRates={fxRates}
          onDeletePosition={handleDeletePosition}
        />
      </div>

      <div className={`section ${activeTab === 'dodaj' ? 'active' : ''}`}>
        <AddETF onAddPosition={handleAddPosition} />
      </div>

      <div className={`section ${activeTab === 'analiza' ? 'active' : ''}`}>
        <Analysis positions={positions} fxRates={fxRates} />
      </div>

      <div className="toast" id="toast"></div>
    </div>
  );
}

export default App;
