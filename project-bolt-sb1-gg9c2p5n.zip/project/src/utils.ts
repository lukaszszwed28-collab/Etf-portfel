import { FXRates } from './types';

export function toPLN(amount: number, currency: string, fxRates: FXRates): number {
  if (currency === 'PLN') return amount;
  const rate = fxRates[currency as keyof FXRates];
  return amount * (rate || 1);
}

export function formatCurrency(amount: number, currency: string = 'PLN'): string {
  return new Intl.NumberFormat('pl-PL', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount) + ' ' + currency;
}

export function formatDate(date: Date): string {
  return date.toLocaleDateString('pl-PL', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });
}

export function showToast(message: string) {
  const toast = document.getElementById('toast');
  if (toast) {
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
  }
}

export async function fetchNBPRate(currency: string): Promise<number | null> {
  try {
    const response = await fetch(
      `https://api.nbp.pl/api/exchangerates/rates/a/${currency}/?format=json`
    );
    const data = await response.json();
    return data.rates[0].mid;
  } catch (error) {
    const fallback = { EUR: 4.25, USD: 3.92, GBP: 4.98 };
    return fallback[currency as keyof typeof fallback] || null;
  }
}
