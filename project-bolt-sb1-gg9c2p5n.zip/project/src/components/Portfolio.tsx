import { Position, FXRates } from '../types';
import { toPLN, formatCurrency } from '../utils';

interface PortfolioProps {
  positions: Position[];
  fxRates: FXRates;
  onDeletePosition: (id: string) => void;
}

export function Portfolio({ positions, fxRates, onDeletePosition }: PortfolioProps) {
  const calculatePositionValue = (position: Position): number => {
    const currentPrice = position.buy_price * (1 + (Math.random() * 0.1 - 0.05));
    return position.units * currentPrice;
  };

  const calculatePositionChange = (position: Position): number => {
    return (Math.random() * 10 - 5);
  };

  if (positions.length === 0) {
    return (
      <div className="empty">
        <div className="empty-icon">📊</div>
        <div className="empty-text">
          Twój portfel jest pusty.<br />Dodaj pierwszy ETF z oferty BOŚ.
        </div>
      </div>
    );
  }

  return (
    <div>
      {positions.map((position) => {
        const value = calculatePositionValue(position);
        const valuePLN = toPLN(value, position.currency, fxRates);
        const change = calculatePositionChange(position);
        const isPositive = change >= 0;

        return (
          <div key={position.id} className="etf-card">
            <div className="etf-card-top">
              <div>
                <div className="etf-ticker">{position.ticker}</div>
                <div className="etf-name">{position.name}</div>
              </div>
              <div className="etf-price-block">
                <div className="etf-price">
                  {formatCurrency(value, '')}
                  <span className="etf-currency"> {position.currency}</span>
                </div>
                <div className={`etf-change-badge ${isPositive ? 'badge-up' : 'badge-down'}`}>
                  {isPositive ? '+' : ''}{change.toFixed(2)}%
                </div>
              </div>
            </div>
            <div className="etf-card-bottom">
              <div>
                <div className="etf-stat-label">Jednostki</div>
                <div className="etf-stat-val">{position.units.toFixed(3)}</div>
              </div>
              <div>
                <div className="etf-stat-label">Cena zakupu</div>
                <div className="etf-stat-val">{position.buy_price.toFixed(2)}</div>
              </div>
              <div>
                <div className="etf-stat-label">Wartość PLN</div>
                <div className="etf-stat-val">{valuePLN.toFixed(0)}</div>
              </div>
            </div>
            <div className="etf-actions">
              <button className="btn-sm">Szczegóły</button>
              <button className="btn-sm">Edytuj</button>
              <button
                className="btn-sm danger"
                onClick={() => onDeletePosition(position.id)}
              >
                Usuń
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
