import { useEffect, useRef } from 'react';
import { Chart, ChartConfiguration, registerables } from 'chart.js';
import { Position, FXRates } from '../types';
import { toPLN } from '../utils';
import { CHART_COLORS } from '../constants';

Chart.register(...registerables);

interface AnalysisProps {
  positions: Position[];
  fxRates: FXRates;
}

export function Analysis({ positions, fxRates }: AnalysisProps) {
  const historyChartRef = useRef<HTMLCanvasElement>(null);
  const allocChartRef = useRef<HTMLCanvasElement>(null);
  const historyChartInstance = useRef<Chart | null>(null);
  const allocChartInstance = useRef<Chart | null>(null);

  useEffect(() => {
    if (historyChartRef.current) {
      const ctx = historyChartRef.current.getContext('2d');
      if (ctx) {
        if (historyChartInstance.current) {
          historyChartInstance.current.destroy();
        }

        const days = 30;
        const labels = Array.from({ length: days }, (_, i) => {
          const d = new Date();
          d.setDate(d.getDate() - (days - i - 1));
          return d.toLocaleDateString('pl-PL', { day: '2-digit', month: 'short' });
        });

        const totalValue = positions.reduce((sum, p) => {
          const value = p.units * p.buy_price;
          return sum + toPLN(value, p.currency, fxRates);
        }, 0);

        const data = Array.from({ length: days }, (_, i) => {
          const variation = Math.sin(i / 5) * 0.05 + (Math.random() - 0.5) * 0.02;
          return totalValue * (1 + variation);
        });

        const config: ChartConfiguration = {
          type: 'line',
          data: {
            labels,
            datasets: [
              {
                label: 'Wartość portfela (PLN)',
                data,
                borderColor: '#00e5a0',
                backgroundColor: 'rgba(0, 229, 160, 0.1)',
                fill: true,
                tension: 0.4,
                borderWidth: 2,
                pointRadius: 0,
                pointHoverRadius: 4,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false,
              },
              tooltip: {
                mode: 'index',
                intersect: false,
                backgroundColor: '#111318',
                titleColor: '#e8ecf0',
                bodyColor: '#e8ecf0',
                borderColor: '#1e2330',
                borderWidth: 1,
              },
            },
            scales: {
              x: {
                grid: {
                  color: '#1e2330',
                  drawBorder: false,
                },
                ticks: {
                  color: '#5a6478',
                  font: {
                    family: 'Space Mono, monospace',
                    size: 10,
                  },
                  maxRotation: 0,
                  autoSkipPadding: 20,
                },
              },
              y: {
                grid: {
                  color: '#1e2330',
                  drawBorder: false,
                },
                ticks: {
                  color: '#5a6478',
                  font: {
                    family: 'Space Mono, monospace',
                    size: 10,
                  },
                  callback: function (value) {
                    return (value as number).toFixed(0);
                  },
                },
              },
            },
            interaction: {
              mode: 'nearest',
              axis: 'x',
              intersect: false,
            },
          },
        };

        historyChartInstance.current = new Chart(ctx, config);
      }
    }

    return () => {
      if (historyChartInstance.current) {
        historyChartInstance.current.destroy();
      }
    };
  }, [positions, fxRates]);

  useEffect(() => {
    if (allocChartRef.current && positions.length > 0) {
      const ctx = allocChartRef.current.getContext('2d');
      if (ctx) {
        if (allocChartInstance.current) {
          allocChartInstance.current.destroy();
        }

        const allocationData = positions.map((p) => {
          const value = p.units * p.buy_price;
          return {
            ticker: p.ticker,
            value: toPLN(value, p.currency, fxRates),
          };
        });

        const total = allocationData.reduce((sum, item) => sum + item.value, 0);

        const config: ChartConfiguration = {
          type: 'doughnut',
          data: {
            labels: allocationData.map((d) => d.ticker),
            datasets: [
              {
                data: allocationData.map((d) => d.value),
                backgroundColor: CHART_COLORS,
                borderColor: '#0a0c10',
                borderWidth: 2,
              },
            ],
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              legend: {
                display: false,
              },
              tooltip: {
                backgroundColor: '#111318',
                titleColor: '#e8ecf0',
                bodyColor: '#e8ecf0',
                borderColor: '#1e2330',
                borderWidth: 1,
                callbacks: {
                  label: function (context) {
                    const value = context.parsed;
                    const percentage = ((value / total) * 100).toFixed(1);
                    return `${value.toFixed(0)} PLN (${percentage}%)`;
                  },
                },
              },
            },
          },
        };

        allocChartInstance.current = new Chart(ctx, config);
      }
    }

    return () => {
      if (allocChartInstance.current) {
        allocChartInstance.current.destroy();
      }
    };
  }, [positions, fxRates]);

  const allocationData = positions.map((p, i) => {
    const value = p.units * p.buy_price;
    const valuePLN = toPLN(value, p.currency, fxRates);
    return {
      ticker: p.ticker,
      value: valuePLN,
      color: CHART_COLORS[i % CHART_COLORS.length],
    };
  });

  const total = allocationData.reduce((sum, item) => sum + item.value, 0);

  if (positions.length === 0) {
    return (
      <div className="empty">
        <div className="empty-icon">📈</div>
        <div className="empty-text">
          Brak danych do analizy.<br />Dodaj pozycje do portfela.
        </div>
      </div>
    );
  }

  return (
    <div>
      <div className="section-subtitle">Historia wartości portfela</div>
      <div className="chart-container">
        <div className="chart-title">Ostatnie 30 dni (symulacja)</div>
        <div style={{ height: '160px' }}>
          <canvas ref={historyChartRef}></canvas>
        </div>
      </div>

      <div className="section-subtitle">Alokacja</div>
      <div className="chart-container">
        <div style={{ height: '160px' }}>
          <canvas ref={allocChartRef}></canvas>
        </div>
        <div className="alloc-list">
          {allocationData.map((item) => {
            const percentage = ((item.value / total) * 100).toFixed(1);
            return (
              <div key={item.ticker} className="alloc-item">
                <div
                  className="alloc-dot"
                  style={{ backgroundColor: item.color }}
                ></div>
                <div className="alloc-name">{item.ticker}</div>
                <div className="alloc-pct">{percentage}%</div>
                <div style={{ flex: 1 }}>
                  <div className="alloc-bar-wrap">
                    <div
                      className="alloc-bar"
                      style={{
                        width: `${percentage}%`,
                        backgroundColor: item.color,
                      }}
                    ></div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
