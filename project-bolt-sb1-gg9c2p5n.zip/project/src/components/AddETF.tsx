import { useState } from 'react';
import { ETFData } from '../types';
import { BOSSA_ETF } from '../constants';

interface AddETFProps {
  onAddPosition: (etf: ETFData, units: number, buyPrice: number) => void;
}

export function AddETF({ onAddPosition }: AddETFProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedETF, setSelectedETF] = useState<ETFData | null>(null);
  const [units, setUnits] = useState('');
  const [buyPrice, setBuyPrice] = useState('');
  const [showResults, setShowResults] = useState(false);

  const searchResults = searchQuery
    ? BOSSA_ETF.filter(
        (etf) =>
          etf.ticker.toLowerCase().includes(searchQuery.toLowerCase()) ||
          etf.name.toLowerCase().includes(searchQuery.toLowerCase())
      ).slice(0, 8)
    : [];

  const handleSelectETF = (etf: ETFData) => {
    setSelectedETF(etf);
    setSearchQuery(etf.ticker);
    setShowResults(false);
  };

  const handleSubmit = () => {
    if (selectedETF && units && buyPrice) {
      onAddPosition(selectedETF, parseFloat(units), parseFloat(buyPrice));
      setSelectedETF(null);
      setSearchQuery('');
      setUnits('');
      setBuyPrice('');
    }
  };

  const isFormValid = selectedETF && units && buyPrice && parseFloat(units) > 0 && parseFloat(buyPrice) > 0;

  return (
    <div className="form-card">
      <div className="form-title">// Szukaj ETF (BOŚ)</div>
      <input
        type="text"
        className="search-box"
        placeholder="Wpisz nazwę lub ticker (np. VWCE, iShares...)"
        value={searchQuery}
        onChange={(e) => {
          setSearchQuery(e.target.value);
          setShowResults(true);
          setSelectedETF(null);
        }}
        onFocus={() => setShowResults(true)}
      />
      {showResults && searchResults.length > 0 && (
        <div className="search-results">
          {searchResults.map((etf) => (
            <div
              key={etf.ticker}
              className="search-item"
              onClick={() => handleSelectETF(etf)}
            >
              <div>
                <div className="search-item-ticker">{etf.ticker}</div>
                <div className="search-item-name">{etf.name}</div>
              </div>
              <div className="search-item-currency">
                {etf.currency}
                <br />
                <span style={{ fontSize: '9px', color: '#3a4455' }}>{etf.exchange}</span>
              </div>
            </div>
          ))}
        </div>
      )}
      {selectedETF && (
        <div className="selected-etf-badge" style={{ display: 'block' }}>
          ✓ {selectedETF.ticker} — {selectedETF.name} ({selectedETF.currency})
        </div>
      )}
      <div className="form-row">
        <div className="form-group">
          <label className="form-label">Liczba jednostek</label>
          <input
            type="number"
            className="form-input"
            placeholder="0.00"
            step="0.001"
            min="0"
            value={units}
            onChange={(e) => setUnits(e.target.value)}
          />
        </div>
        <div className="form-group">
          <label className="form-label">Cena zakupu</label>
          <input
            type="number"
            className="form-input"
            placeholder="0.00"
            step="0.01"
            min="0"
            value={buyPrice}
            onChange={(e) => setBuyPrice(e.target.value)}
          />
        </div>
      </div>
      <button
        className="btn-primary"
        onClick={handleSubmit}
        disabled={!isFormValid}
      >
        Dodaj do portfela
      </button>
    </div>
  );
}
