import { FXRates } from '../types';

interface CurrencyBarProps {
  fxRates: FXRates;
  loading: boolean;
}

export function CurrencyBar({ fxRates, loading }: CurrencyBarProps) {
  const currencies = [
    { pair: 'EUR/PLN', key: 'EUR' as const },
    { pair: 'USD/PLN', key: 'USD' as const },
    { pair: 'GBP/PLN', key: 'GBP' as const },
  ];

  return (
    <>
      <div className="section-subtitle">Kursy walut (NBP)</div>
      <div className="fx-bar">
        {currencies.map(({ pair, key }) => (
          <div key={key} className="fx-chip">
            <div className="fx-pair">{pair}</div>
            <div className="fx-rate">
              {fxRates[key] ? fxRates[key]!.toFixed(4) : '—'}
            </div>
            <div className="fx-status">
              {loading ? (
                <span className="loading-dot"></span>
              ) : fxRates[key] ? (
                'NBP'
              ) : (
                'offline'
              )}
            </div>
          </div>
        ))}
      </div>
    </>
  );
}
