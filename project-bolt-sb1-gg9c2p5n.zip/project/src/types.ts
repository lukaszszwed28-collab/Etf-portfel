export interface ETFData {
  ticker: string;
  name: string;
  currency: 'EUR' | 'USD' | 'GBP' | 'PLN';
  exchange: string;
}

export interface Position {
  id: string;
  user_id: string;
  ticker: string;
  name: string;
  currency: string;
  exchange: string;
  units: number;
  buy_price: number;
  created_at: string;
  updated_at: string;
}

export interface FXRates {
  EUR: number | null;
  USD: number | null;
  GBP: number | null;
  PLN: number;
}

export type TabType = 'portfel' | 'dodaj' | 'analiza';
