/*
  # Create ETF Portfolio Schema

  1. New Tables
    - `positions`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `ticker` (text) - ETF ticker symbol
      - `name` (text) - ETF name
      - `currency` (text) - Currency (EUR, USD, GBP, PLN)
      - `exchange` (text) - Exchange name
      - `units` (numeric) - Number of units owned
      - `buy_price` (numeric) - Purchase price per unit
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `positions` table
    - Add policy for authenticated users to read their own positions
    - Add policy for authenticated users to insert their own positions
    - Add policy for authenticated users to update their own positions
    - Add policy for authenticated users to delete their own positions
*/

CREATE TABLE IF NOT EXISTS positions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  ticker text NOT NULL,
  name text NOT NULL,
  currency text NOT NULL,
  exchange text NOT NULL,
  units numeric NOT NULL DEFAULT 0,
  buy_price numeric NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE positions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own positions"
  ON positions
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own positions"
  ON positions
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own positions"
  ON positions
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own positions"
  ON positions
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS positions_user_id_idx ON positions(user_id);
CREATE INDEX IF NOT EXISTS positions_ticker_idx ON positions(ticker);